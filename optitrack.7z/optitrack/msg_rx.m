function msg_rx(varargin)
%SUBSCRIBE Summary of this function goes here
%   Detailed explanation goes here
    client = varargin{1}
    userdata = varargin{2}
    message = varargin{3}
    fprintf("msg received")
    fprintf(client)
    fprintf(message)
end

