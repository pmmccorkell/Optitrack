
from time import sleep
import paho.mqtt.client as MQTT
from gc import collect as trash

class sub(object):
	def __init__(self,server='10.60.69.244',name='H023'):
		#                       #
		#-------MQTT Setup------#
		#                       #
		self.clientname=name
		self.client=MQTT.Client(self.clientname)
		#self.mqtt_server='10.60.69.243'	# laptop H208
		#self.mqtt_server='10.60.17.244'	# laptop H023
		#self.mqtt_server='10.60.69.244'	# OptiTrack H208
		self.mqtt_server=server
		self.client.reinitialise(self.clientname)
		self.client.connect(self.mqtt_server)

		self.topiclist=[
			'test'
		]
		print('lalala')
		trash()

	# basic callback for MQTT that prints message data directly.
	def SUBSCRIPTION_CALLBACK(self,client,userdata,message):
		print()
		print("mqtt rx:")
		print(message.topic)
		print(message.qos)
		#print(message.payload)
		print(message.payload.decode())
		print(message.retain)
		print(client)

	def test(self):
		print('is it loading')

	def add_topic(self,new_topic):
		self.topiclist.append(new_topic)
		self.client.subscribe(new_topic)

	def reset(self):
		self.client.disconnect()
		self.client.reinitialise(self.clientname)
		self.client.connect(self.mqtt_server)

	def publish(self,topic,msg):
		self.client.publish(topic,msg)
		print("published: "+topic+", "+msg)

	def setup_subscription(self):
		# Connect to the server
		self.reset()
		self.client.on_message=self.SUBSCRIPTION_CALLBACK

		# Subscribes to all the topics defined at top.
		for i in self.topiclist:
			self.client.subscribe(i)
			print("subscribed to: "+str(i))

		# Start the mqtt subscription.
		self.client.loop_start()
		print("Connected to MQTT server: "+self.mqtt_server)
		trash()



